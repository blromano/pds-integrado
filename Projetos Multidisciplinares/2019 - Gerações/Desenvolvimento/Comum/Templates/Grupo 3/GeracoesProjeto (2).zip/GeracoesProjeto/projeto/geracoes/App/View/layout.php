<!DOCTYPE html>
<html>
    <head>
        <title>Projeto Gerações</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <link href="../../CSS/style.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
        <header>
            <!-- MENU !-->
            <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="navbar">
                <div class="container">
                    <a href="/" class="navbar-brand">
                        <img src="../../images/sizeimg.png" alt=""/>
                    </a>
                    <a href="/" class="navbar-brand">
                        Gerações
                    </a>
                    <div class="collapse navbar-collapse" id="nav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item active"><a href="/" class="nav-link">Home</a></li>
                            <li class="nav-item"><a href="" class="nav-link">Conheça-nos</a></li>
                            <li class="nav-item"><a href="/login" class="btn btn-outline-light ml-4" style="font-size: 12px;padding:20px 40px;line-height:0; ">Entrar</a></li>   
                            <li class="nav-item"><a href="/cadastro" class="btn btn-outline-light ml-4" style="font-size: 12px;padding:20px 40px;line-height:0;">Cadastrar</a></li> 
                        </ul>
                    </div>
                </div>
            </nav>
        </header>
        <?php $this->content() ?>

        <section>
            <footer class="site-footer ">
                <div class="footer-widgets">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-3">
                                <div class="foot-about">
                                    <h2><a class="foot-logo" href="#"><img src="../../images/logosite.png" alt=""></a></h2>

                                    <p>Somos uma casa de idosos dispostas a ajudar você.</p>

                                    <ul class="d-flex flex-wrap align-items-center">
                                        <li><a href="instagra.com"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="facebook.com"><i class="fab fa-facebook"></i></a></li>
                                        <li><a href="twitter.com"><i class="fab fa-twitter"></i></a></li>

                                    </ul>
                                </div><!-- .foot-about -->
                            </div><!-- .col -->

                            <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                                <h2>Links Uteis</h2>

                                <ul>
                                    <li><a href="/">Principal</a></li>
                                    <li><a href="doacoes">Docações</a></li>
                                    <li><a href="/sobre">Sobre nos</a></li>
                                </ul>
                            </div><!-- .col -->


                            <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                                <div class="foot-contact">
                                    <h2>Contact</h2>

                                    <ul>
                                        <li><i class="fa fa-phone"></i><span>(19)99999999</span></li>
                                        <li><i class="fa fa-envelope"></i><span>Exemplo@gmail.com.com</span></li>
                                        <li><i class="fa fa-map-marker"></i><span>Endereco</span></li>
                                    </ul>
                                </div><!-- .foot-contact -->

                                <div class="subscribe-form">
                                    <form class="d-flex flex-wrap align-items-center">
                                        <input type="email" placeholder="Seu email para contato">
                                        <input type="submit" value="send">
                                    </form><!-- .flex -->
                                </div><!-- .search-widget -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .footer-widgets -->

                <div class="footer-bar">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <p class="m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                    All rights reserved | This template was made by Matheus e Heloisa</a>
                                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                            </div><!-- .col-12 -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .footer-bar -->
            </footer><!-- .site-footer -->
        </section>
        
   <script src="../../../JS/circle-progress.min.js" type="text/javascript"></script>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
         
    </body>
</html>

