<?php
    
    namespace App\Controller;
    
    use FW\Controller\Action;

    class IndexController extends Action{
                                
        public function index(){
            $this->render('index');
        }
        
        public function login(){
            $this->render('login');
        }       
        
         public function cadastro(){
            $this->render('cadastro');
        } 
        
        public function index2(){
            $this->render('index2');
        } 
       
    }

?>
