<?php

    namespace App;
    
    use FW\Init\Bootstrap;
    
    class Route extends Bootstrap{
                
        protected function initRoutes(){
            
            $routes['index'] = array(
                'route' => '/',
                'controller' => 'IndexController',
                'action' => 'index'
            );            
            
            $routes['login'] = array(
                'route' => '/login',
                'controller' => 'IndexController',
                'action' => 'login'
            );         
            
            $routes['cadastro'] = array(
                'route' => '/cadastro',
                'controller' => 'IndexController',
                'action' => 'cadastro'
            );
            
            $routes['index2'] = array(
                'route' => '/index2',
                'controller' => 'IndexController',
                'action' => 'index2'
            );
            
            $this->setRoutes($routes);
            
        }        
                        
    }

?>
