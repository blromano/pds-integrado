<!DOCTYPE html>
<!--
    Nome: Antônio
-->
<html>
    <head>
        <title>Gerações</title>
        <meta charset="UTF-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        
        <link href="css/estilos.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-light bg-warning">
                <div class="container">
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#nav-principal">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="nav-principal">
                        <ul class="navbar-nav ml-auto">
                            <li class="navbar-item">
                                <a href="SobreNos.php" class="nav-link">Sobre nós</a>
                            </li>
                            <li class="navbar-item">
                                <a href="objetivo.php" class="nav-link">Objetivo</a>
                            </li>
                            <li class="navbar-item">
                                <a href="FaleConosco.php" class="nav-link">Fale conosco</a>
                            </li>
                            <li class="navbar-item">
                                <a href="RecupereSuaSenha.php" class="nav-link">Recupere sua senha</a>
                            </li>
                           <li class="navbar-item">
                               <a href="cadastro.php" class="btn btn-outline-light ml-4">Cadastre-se</a>
                            </li>
                            <li class="navbar-item">
                                <a href="login.php" class="btn btn-outline-light ml-4">Logar</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>        
                
        <section class="bg-primary text-white text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 d-flex">
                        <div class="align-self-center">
                            <h1 class="text-uppercase mb-0">Site Web para o auxílio de Instituições de Longa Permanência</h1>
                        </div>
                    </div>
                    <div class="col-md-6 d-none d-md-block">
                        <img src="imagens/logo.png" alt=""/>
                    </div>
                </div>
            </div>       
        </section>             

        <footer class="mt-4 mb-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <p>
                            <a href="SobreNos.php">Sobre nós</a>&nbsp;&nbsp;&nbsp;
                            <a href="objetivo.php">Objetivo</a>&nbsp;&nbsp;&nbsp;
                            <a href="FaleConosco.php">Fale conosco</a>&nbsp;&nbsp;&nbsp;
                            <a href="RecupereSuaSenha.php">Recupere sua senha</a>&nbsp;&nbsp;&nbsp;
                        </p>
                    </div>                    
                </div>
            </div>
        </footer>
        
        <?php
        
        ?>       
        
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>
