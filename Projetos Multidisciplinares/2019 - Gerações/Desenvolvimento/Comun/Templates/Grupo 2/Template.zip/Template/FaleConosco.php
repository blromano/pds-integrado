<!DOCTYPE html>
<!--
    Nome: Antônio
-->
<html>
    <head>
        <title>Fale Conosco</title>
        <meta charset="UTF-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        
        <link href="css/estilos.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-light bg-warning">
                <div class="container">
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#nav-principal">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="nav-principal">
                        <ul class="navbar-nav ml-auto">
                            <li class="navbar-item">
                                <a href="index.php" class="nav-link">Página inicial</a>
                            </li>                            
                        </ul>
                    </div>
                </div>
            </nav>
        </header>        
                
        <section class="bg-primary text-white text-center">
            <div class="container">
                <div class="row">
                    <h1 class="display-4">Dúvidas e Feedbacks</h1>                     
                </div>
            </div>
        </section>        
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <p class="lead">
                        Está com alguma dúvida? Deseja fazer reclamações? Não se preocupe!
                    </p>                   
                    <p class="lead">
                        Com Gerações é possível cessar suas dúvidas e fazer reclamações!!! 
                    </p>                        
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row"> 
                    <h2 class="text-uppercase mb-0">
                        Tire suas                  
                    </h2>                            
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <h2 class="text-uppercase mb-0">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;dúvidas
                    </h2>                       
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <h2 class="text-uppercase mb-0">
                        e
                    </h2>                     
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <h2 class="text-uppercase mb-0">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;faça
                    </h2>                       
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                     <h2 class="text-uppercase mb-0">
                        reclamações e sugestões
                    </h2>                         
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <h2 class="text-uppercase mb-0">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;em
                    </h2>                       
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <a href="" class="btn btn-outline-dark">
                        <span class="fab fa-facebook"></span>
                    </a>                   
                </div>
            </div>
        </section>
        <section class="bg-primary text-white">
            <div class="container">
                <div class="row">
                    <p>
                        
                    </p>                    
                </div>
            </div>
        </section>
               
        <footer class="mt-4 mb-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <p>
                            <a href="index.php">Página inicial</a>&nbsp;&nbsp;&nbsp;                            
                        </p>
                    </div>                    
                </div>
            </div>
        </footer>
        
        <?php
        
        ?>       
        
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>
