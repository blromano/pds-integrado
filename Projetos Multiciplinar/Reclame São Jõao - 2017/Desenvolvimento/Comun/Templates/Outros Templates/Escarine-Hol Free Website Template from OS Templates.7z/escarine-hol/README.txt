
Please note:

This template uses elements that are NOT supported by Internet Explorer 9 and below

We have used CSS gradients and transitions in this template that are supported by Internet Explorer starting from IE10

We have added fallbacks that IE9 needs for colouring

Elements that have a transition still work in IE9, they simply change state using a hard change instead of a slow fade