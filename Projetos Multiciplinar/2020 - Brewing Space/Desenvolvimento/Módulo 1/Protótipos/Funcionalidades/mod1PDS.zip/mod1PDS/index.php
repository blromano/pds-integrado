<!DOCTYPE html>
<html>
    <head>
        <title>Brewing Space</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="includes/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="includes/css/estilo.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark bg-dark">
                <div class="container-fluid">
                    
                    <a href="#" class="navbar-brand">
                        <img class="logo" src="includes/img/Logo-2-Transparente.png">
                    </a>
                    
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#nav-principal">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse" id="nav-principal">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="index.html" class="nav-link active">Início</a>
                            </li>
                            <li class="nav-item">
                                <a href="includes/prototipos/Enviar_Feedback.html" class="nav-link ml-3">Fale conosco</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link ml-3">Planos</a>
                            </li>
                            <li class="nav-item">
                                <a href="includes/prototipos/Sobre_IFSP.html" class="nav-link ml-3">IFSP</a>
                            </li>
                            <li class="nav-item">
                                <a href="includes/prototipos/InformacaoUsuario.html" class="nav-link ml-3">Informações de Usuário</a>
                            </li>
                            <li class="nav-item">
                                <a href="includes/prototipos/Editar_Perfil.html" class="nav-link ml-3">Editar Perfil Usuário</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a href="includes/prototipos/Cadastro.html" class="btn btn-outline-light">Cadastrar</a>
                            </li>
                        </ul>
                    </div>
                    
                </div>               
            </nav>            
        </header>
        
        <section>
            <div class="container-fluid imagemDeMadeira">
                <div class="row form justify-content-center">
                    <div class="col-6 align-self-center">
                        <form id="formulario-login">
                            <h3>Login</h3>
                            <div class="form-group">
                              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu email">
                            </div>
                            <div class="form-group">
                              <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Senha">
                              <small>
                                <a href="includes/prototipos/Recuperar_Senha.html" class="text-dark">Esqueci minha senha</a>
                              </small>
                            </div>
                            <button type="submit" class="btn btn-dark">Entrar</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="my-5">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h1 class="display-4">Cerveja agora? É a feita em casa!</h1>
                        <p class="lead">Plataforma usada pelos melhores mestres cervejeiros da região!!! Não fiquei de fora dessa, faça logo seu cadastro!</p>
                    </div>
                </div>
            </div>
        </section>        
        
        <section>
            <div class="container my-5">
                <div class="row">
                    <div class="col-md-6 align-self-center">
                        <h2>Aprenda Receitas</h2>
                        <p>Aprenda as melhores receitas sem erro!</p>
                        <a href="#" class="btn btn-dark">Veja mais</a>
                    </div>
                    <div class="col-md-6">
                        <img class="img-fluid imagensVejaMais" src="includes/img/fermentacao.png">
                    </div>
                </div>
                <hr>
            </div>
        </section>
        
        <section>
            <div class="container">
                <div class="row border-bottom">
                    <div class="col my-3">
                        <img class="img-fluid imagensVejaMais" src="includes/img/comunicacao.png">
                    </div>                    
                    <div class="col align-self-center my-3">
                        <h2>Compartilhe experiências</h2>
                        <p>Compartilhe suas experiências com cada receita, outros também</p>
                        <a href="#" class="btn btn-dark">Veja mais</a>
                    </div>
                </div>
                <hr>
            </div>
        </section>
        
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center my-3">
                    <h2>As melhores cervejas</h2>
                    <p>Veja quais são as cervejas melhores avaliadas!</p>
                    <a href="#" class="btn btn-dark">Veja mais</a>
                </div>
                <div class="col-md-6 my-5">
                    <img class="img-fluid imagensVejaMais" src="includes/img/cerveja.png">
                </div>
            </div>
        </div>
        
        <section>
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="display-4 text-lg-center">Saiba mais...</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <p class="h5 text-center">Sobre o Instituto Federal</p>
                                <img class="imagensSaibaMais" src="includes/img/escola.png">
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <p class="h5 text-center">Sobre a equipe</p>
                                <img class="imagensSaibaMais" src="includes/img/equipe.png" alt="receitas">
                            </div>
                            <a href="includes/prototipos/Equipe.html"></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <footer class="mt-5">
            <div class="container-fluid bg-dark">
                <div class="row">
                    <div class="col">
                        <p class="lead text-center text-white">
                            © Copyright 4° ano de infomática do ano de 2020. Todos os Direitos Reservados.
                        </p>
                    </div>
                </div>
            </div>
        </footer>        
    </body>
</html>
