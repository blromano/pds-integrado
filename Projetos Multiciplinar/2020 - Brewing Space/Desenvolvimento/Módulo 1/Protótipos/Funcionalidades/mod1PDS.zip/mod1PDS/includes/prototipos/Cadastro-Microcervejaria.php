<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/estilo.css" rel="stylesheet" type="text/css"/>
<script src="../js/js.js" type="text/javascript"></script>
<?php 
$nomeEmp = $_POST['nomeEmp'];
$email = $_POST['email'];
$nomeMicro = $_POST['nomeMicro'];
$cnpj = $_POST['cnpj'];
$tel = $_POST['tel'];
$desc = $_POST['desc'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$UF = $_POST['UF'];
$cep = $_POST['cep'];
$facebook = $_POST['facebook'];
$instagram = $_POST['instagram'];

$pdo = new PDO('mysql:host=localhost;dbname=PDS',"root","");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    try{
        $sql = $pdo->prepare('INSERT INTO microcervejarias '
                . '(MIC_NOME, MIC_EMAIL, MIC_NOME_EMPRESARIO, MIC_CNPJ, MIC_TELEFONE, MIC_DESCRICAO, MIC_RUA, MIC_NUMERO, MIC_BAIRRO,'
                . ' MIC_CIDADE, MIC_ESTADO, MIC_CEP, MIC_FACEBOOK, MIC_INSTAGRAM) '
                . 'VALUES (:nomeEmp, :email, :nomeMicro, :cnpj, :tel, :desc, :rua, :numero, :bairro, :cidade, :UF, :cep, :facebook, :instagram);');
        $sql->execute(array(
            ':nomeEmp' => $nomeEmp,
            ':email' => $email,
            ':nomeMicro' => $nomeMicro,
            ':cnpj' => $cnpj,
            ':tel' => $tel,
            ':desc' => $desc,
            ':rua' => $rua,
            ':numero' => $numero,
            ':bairro' => $bairro,
            ':cidade' => $cidade,
            ':UF' => $UF,
            ':cep' => $cep,
            ':facebook' => $facebook,
            ':instagram' => $instagram,
        ));
        $message = "Cadastro Bem Sucecido";
        echo "<script type='text/javascript'>alert('$message');</script><br />";
        } catch (PDOException $ex) {
            echo 'Error ' . $ex->getMessage();
            $message = "Erro no cadastro";
            echo "<script type='text/javascript'>alert('$message');</script><br />";
        }
?>
<a href="../../index.php"><button type="button" class="btn btn-dark">Página Inicial</button></a>
       