<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/estilo.css" rel="stylesheet" type="text/css"/>
<script src="../js/js.js" type="text/javascript"></script>
<?php 
$cpf = $_POST['cpf'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$pdo = new PDO('mysql:host=localhost;dbname=PDS',"root","");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try{
    $sql = $pdo->prepare('update usuarios set USU_NOME_COMPLETO = :nome, USU_EMAIL = :email where USU_CPF = :cpf');
    $sql->execute(array(
        ':nome' => $nome,
        ':email' => $email,
        ':cpf' => $cpf,
    ));
        $message = "Atualização Bem Sucecida";
        echo "<script type='text/javascript'>alert('$message');</script><br />";
        
} catch (PDOException $ex) {
    echo 'Error ' . $ex->getMessage();
    $message = "Erro na atualização";
    echo "<script type='text/javascript'>alert('$message');</script><br />";
}
?>
<a href="../../index.php"><button type="button" class="btn btn-dark">Página Inicial</button></a>
