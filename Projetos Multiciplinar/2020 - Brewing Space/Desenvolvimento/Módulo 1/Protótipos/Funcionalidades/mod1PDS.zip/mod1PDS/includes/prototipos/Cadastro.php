<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/estilo.css" rel="stylesheet" type="text/css"/>
<script src="../js/js.js" type="text/javascript"></script>
<?php 
$nome = $_POST['nome'];
$email = $_POST['email'];
$cpf = $_POST['cpf'];
$data = $_POST['data'];
$senha = $_POST['senha'];
$senhaconfirma = $_POST['senhaconfirma'];
$pdo = new PDO('mysql:host=localhost;dbname=PDS',"root","");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    try{
        $sql = $pdo->prepare('INSERT INTO usuarios (USU_NOME_COMPLETO, USU_EMAIL, USU_CPF, USU_DATA_NASCIMENTO, USU_SENHA) VALUES (:nome, :email, :cpf, :data, :senha);');
        $sql->execute(array(
         ':nome' => $nome,
         ':email' => $email,
         ':cpf' => $cpf,
         ':data' => $data,
         ':senha' => $senha,
        ));
        $message = "Cadastro Bem Sucecido";
        echo "<script type='text/javascript'>alert('$message');</script><br />";
        } catch (PDOException $ex) {
            echo 'Error ' . $ex->getMessage();
            $message = "Erro no cadastro";
            echo "<script type='text/javascript'>alert('$message');</script><br />";
        }
?>
<a href="../../index.php"><button type="button" class="btn btn-dark">Página Inicial</button></a>
       
