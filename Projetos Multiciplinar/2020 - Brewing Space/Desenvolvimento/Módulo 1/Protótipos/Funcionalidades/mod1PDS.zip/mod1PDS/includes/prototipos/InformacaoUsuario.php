<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/estilo.css" rel="stylesheet" type="text/css"/>
<script src="../js/js.js" type="text/javascript"></script>
<?php 
$cpf = $_POST['cpf'];
$pdo = new PDO('mysql:host=localhost;dbname=PDS',"root","");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try{
    $sql = $pdo->query("select USU_NOME_COMPLETO, USU_EMAIL, USU_CPF, USU_DATA_NASCIMENTO, USU_SENHA from usuarios where USU_CPF = $cpf;");
    $row;
    
    while($row = $sql->fetch(PDO::FETCH_ASSOC)){
        echo "Nome: {$row['USU_NOME_COMPLETO']} - Email: {$row['USU_EMAIL']} - CPF: {$row['USU_CPF']} - Data de nascimento: {$row['USU_DATA_NASCIMENTO']} - Senhha: {$row['USU_SENHA']} <br />";
    }
    
} catch (PDOException $ex) {
    echo 'Error ' . $ex->getMessage();
    $message = "Erro na consulta";
    echo "<script type='text/javascript'>alert('$message');</script><br />";
}
?>
<a href="../../index.php"><button type="button" class="btn btn-dark">Página Inicial</button></a>
