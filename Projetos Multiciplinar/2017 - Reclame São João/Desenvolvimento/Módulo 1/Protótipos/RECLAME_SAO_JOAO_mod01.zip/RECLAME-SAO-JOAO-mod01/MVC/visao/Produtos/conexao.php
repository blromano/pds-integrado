<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "estabelecimentos";
	
	//Criar a conexão
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>