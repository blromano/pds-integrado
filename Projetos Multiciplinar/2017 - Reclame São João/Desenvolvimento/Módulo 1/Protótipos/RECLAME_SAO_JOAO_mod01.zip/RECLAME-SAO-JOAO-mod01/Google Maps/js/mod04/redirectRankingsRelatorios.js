function irParaRankings() {

    window.location = 'rankings.html'

};

function irParaRelatorios() {

    window.location = 'relatorios.html'

};
