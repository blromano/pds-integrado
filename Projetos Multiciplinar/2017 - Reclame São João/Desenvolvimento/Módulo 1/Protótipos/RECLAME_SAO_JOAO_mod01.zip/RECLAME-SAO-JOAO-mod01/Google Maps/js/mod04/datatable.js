$(document).ready(function() {
    $('.table').DataTable({
		"lengthChange": false,
		"paging":   false,
		"info":     false,
		"filter":     false,
		
	});
	
} );