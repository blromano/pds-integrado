$(document).ready(function() {
    $('.tableJS').DataTable({
		"lengthChange": false,
		"paging":   false,
		"info":     false,
		"filter":     false,

	});

	 $('.relatorioTabular').DataTable({
// 		"lengthChange": false,
// "paging":   false,
// 		"info":     false,
// 		"filter":     false,

	});

} );
