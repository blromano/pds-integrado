

<html>
<head>
<title>Sample Chat Application</title>


<link type="text/css" rel="stylesheet" media="all" href="css/chat.css" />
<link type="text/css" rel="stylesheet" media="all" href="css/screen.css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/chat.js"></script>
<!--[if lte IE 7]>
<link type="text/css" rel="stylesheet" media="all" href="css/screen_ie.css" />
<![endif]-->

</head>
<body>
<div id="main_container">

<a href="javascript:void(0)" onclick="javascript:chatWith('janedoe')">janedoe</a>
<a href="javascript:void(0)" onclick="javascript:chatWith('john')"> John </a>
<a href="javascript:void(0)" onclick="javascript:chatWith('mevan')"> mevan </a>
<!-- YOUR BODY HERE -->

</div>



</body>
</html>