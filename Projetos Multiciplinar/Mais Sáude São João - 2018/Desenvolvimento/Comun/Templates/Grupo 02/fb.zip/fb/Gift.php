<html>
<head>
<style>
#header{
	width:100%;
	height:50px;
	color:#FFFFFF;
	text-align:center;
	font-size:46px;
	font-weight:bold;
	font-family:sans serif;
}
#video{
	
	width:80%;
	height:400px;
	border-top:3px solid blue;
	border-bottom:3px solid blue;
	border-left:3px solid blue;
	border-right:3px solid blue;
    margin-left:160px;
}
#foot{
	
	width:80.5%;

	border-top:3px solid blue;
	border-bottom:3px solid blue;
	border-left:3px solid blue;
	border-right:3px solid blue;
    margin-left:160px;
	
}
a
{
	text-decoration:none;
	font-size:20px;
	color:gray;
	font-weight:bold;
	font-family:sans-serif;
}
</style>
<title>Gift</title>
</head>
<div id="header">
Hey!!! babu Enjoy The Love Framework. <a href="index.php">See My Original Gift</a>
</div>
<body background="l.jpg">

<div id="video" align="center">

<video width="500" height="395" controls>
  <source src="M.mp4" type="video/mp4">
 
Your browser does not support the video tag.
</video>
<video width="490" height="340" controls>
  <source src="LD.mp4" type="video/mp4">
 
Your browser does not support the video tag.
</video>



</div>
<div id="foot" align="">
<marquee>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>
<img src="pic/a.jpg" width="150" height:"120"/>
<img src="pic/b.jpg" width="150" height:"120"/>
<img src="pic/c.jpg" width="150" height:"120"/>
<img src="pic/d.jpg" width="150" height:"120"/>
<img src="pic/f.jpg" width="150" height:"120"/>
<img src="pic/g.jpg" width="150" height:"120"/>
<img src="pic/h.jpg" width="150" height:"120"/>

</marquee>
</div>
</body>
</html>